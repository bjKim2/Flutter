package com.example.crud_insert_result_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
